import '../../../export/exports.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../../../features/visits/presentation/providers/visits_provider.dart';
import '../../../../features/visits/presentation/providers/job_details_provider.dart';
import '../../../../features/visits/data/models/visit_model.dart';
import '../../../../shared/presentation/widgets/signature_capture_widget.dart';
import '../../../../router/app_router.dart';
import '../../../../core/validation/validation_rules.dart';
import 'package:intl/intl.dart';

class JobDetailsScheduleWidget extends ConsumerWidget {
  const JobDetailsScheduleWidget({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final visitId = ref.watch(selectedVisitIdProvider);
    
    // Fallback: use first visit from today's visits if no visitId
    final todayVisits = ref.watch(todayVisitsProvider).value;
    final effectiveVisitId = visitId ?? (todayVisits?.isNotEmpty == true ? todayVisits!.first.id : null);
    
    if (effectiveVisitId == null) {
      return SizedBox.shrink();
    }

    final visitAsync = ref.watch(visitDetailsProvider(effectiveVisitId));
    
    return visitAsync.when(
      data: (visit) => Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Schedule',
            style: AppTextStyles.bodyMedium.copyWith(
              fontWeight: FontWeight.bold,
              fontSize: 18.sp,
              color: Colors.black87,
            ),
          ),
          SizedBox(height: 4.h),
          Text(
            _formatScheduleRange(visit.scheduledStart, visit.scheduledEnd),
            style: AppTextStyles.bodyMedium.copyWith(color: Colors.black87),
          ),
          Text(
            'Arriving between ${_formatTime(visit.scheduledStart)} – ${_formatTime(visit.scheduledEnd)}',
            style: AppTextStyles.bodyMedium.copyWith(color: Colors.black87),
          ),
          SizedBox(height: 12.h),
          Row(
            children: [
              // Start Timer button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: visit.canStart
                      ? () async {
                          final success = await ref
                              .read(visitActionsProvider.notifier)
                              .startVisit(effectiveVisitId);
                          if (success && context.mounted) {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text('Visit started')),
                            );
                          }
                        }
                      : null,
                  icon: Icon(Icons.play_circle_outline, color: Colors.white),
                  label: Text(
                    'Start Timer',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14.h),
                    backgroundColor: visit.canStart
                        ? AppColors.primaryColor
                        : AppColors.greyColor,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              // Completed button
              Expanded(
                child: ElevatedButton.icon(
                  onPressed: visit.canComplete
                      ? () async {
                          // Validate visit can be completed
                          final validation = ValidationRules.canCompleteVisit(
                            currentStatus: visit.status,
                            hasSignature: false, // Will be captured below
                          );
                          
                          if (!validation.isValid) {
                            if (context.mounted) {
                              context.showErrorSnackBar(
                                validation.errorMessage ?? 'Cannot complete visit',
                              );
                            }
                            return;
                          }

                          // Show signature capture dialog
                          final signaturePath = await showDialog<String>(
                            context: context,
                            builder: (context) => SignatureCaptureWidget(),
                          );

                          if (signaturePath == null) {
                            // User cancelled signature
                            return;
                          }

                          // Validate again with signature
                          final validationWithSignature = ValidationRules.canCompleteVisit(
                            currentStatus: visit.status,
                            hasSignature: true,
                          );
                          
                          if (!validationWithSignature.isValid) {
                            if (context.mounted) {
                              context.showErrorSnackBar(
                                validationWithSignature.errorMessage ?? 'Cannot complete visit',
                              );
                            }
                            return;
                          }

                          // Complete visit with signature
                          final success = await ref
                              .read(visitActionsProvider.notifier)
                              .completeVisit(effectiveVisitId, signaturePath: signaturePath);
                          if (success && context.mounted) {
                            context.showSuccessSnackBar('Visit completed');
                          }
                        }
                      : null,
                  icon: Icon(Icons.check, color: Colors.white),
                  label: Text(
                    'Completed',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  style: ElevatedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    padding: EdgeInsets.symmetric(vertical: 14.h),
                    backgroundColor: visit.canComplete
                        ? AppColors.successGreen
                        : AppColors.greyColor,
                  ),
                ),
              ),
              SizedBox(width: 12.w),
              // More button (Quote Builder)
              SizedBox(
                height: 48.h,
                width: 48.h,
                child: OutlinedButton(
                  onPressed: () {
                    // Navigate to create quotes screen with visitId
                    context.goToCreateQuotes(effectiveVisitId!);
                  },
                  style: OutlinedButton.styleFrom(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(12.0),
                    ),
                    side: BorderSide(color: AppColors.greyColor.withAlpha(80)),
                    padding: EdgeInsets.zero,
                  ),
                  child: Icon(Icons.more_horiz, color: Colors.black87),
                ),
              ),
            ],
          ),
        ],
      ),
      loading: () => Center(child: CircularProgressIndicator()),
      error: (error, stack) => Text(
        'Error loading schedule',
        style: AppTextStyles.bodyMedium.copyWith(color: AppColors.errorRed),
      ),
    );
  }

  String _formatScheduleRange(DateTime start, DateTime end) {
    final dateFormat = DateFormat('MMM d');
    final timeFormat = DateFormat('h:mm a');
    
    final startDate = dateFormat.format(start);
    final startTime = timeFormat.format(start);
    final endTime = timeFormat.format(end);
    
    return '$startDate, $startTime – $endTime';
  }

  String _formatTime(DateTime time) {
    return DateFormat('h:mm a').format(time);
  }
}
